# Testes

- Carregar dados iniciais de teste:

    ```bash
    python manage.py loaddata djangosige/tests/fixtures/test_db_backup.json
    ```

- Realizar testes:
    
    ```bash
    python manage.py test
    ```
