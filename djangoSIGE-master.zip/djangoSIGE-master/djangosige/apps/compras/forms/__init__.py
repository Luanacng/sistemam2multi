# -*- coding: utf-8 -*-

from .compras import *
from .pagamento import *
