# -*- coding: utf-8 -*-

from .natureza_operacao import *
from .tributos import *
from .nota_fiscal import *
